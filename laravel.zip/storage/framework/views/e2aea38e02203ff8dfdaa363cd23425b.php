


<?php $__env->startSection('content'); ?>
<div class="card card-data col-md-12">
    <h1 style="color: #34495e; margin: 30px 0 30px 0; font-weight: bold; text-align: center;">Laporan Penjualan</h1>
    <div class="row">
        <div class="col-md-12 col-xs-12">
            <div class="row" style="margin: 0 10px 10px 10px;">
                <div class="col-md-8">
                    <a href="<?php echo e(url('downloadpdf-produk')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak
                        </button>
                    </a>
                </div>
                <div class="col-md-4">
                    <form class="d-flex" action="<?php echo e(url('admin-laporanpenjualan')); ?>" method="GET">
                        <input type="date" class="form-control me-2" id="tanggal" name="tanggal">
                        <button type="submit" class="btn btn-primary">Cari</button>
                        <?php if(isset($tanggal)): ?>
                        <a href="<?php echo e(url('admin-laporanpenjualan')); ?>" class="btn btn-secondary ms-2">All</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="table-responsive" style="width: 97%; margin-left: 15px;">
            <table class="table table-responsive table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">Waktu</th>
                        <th class="text-center">No Order</th>
                        <th class="text-center">Produk</th>
                        <th class="text-center">Harga</th>
                        <th class="text-center">QTY</th>
                        <th class="text-center">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($mergedDetail) && count($mergedDetail) > 0): ?>
                    <?php $__currentLoopData = $mergedDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center"><?php echo e($no+1); ?></td>
                        <td align="center"><?php echo e($detail->created_at); ?></td>
                        <?php if($detail instanceof App\Models\PenjualanDetail): ?>
                        <td align="center"><?php echo e($detail->penjualan->no_order); ?></td>
                        <td align="center"><?php echo e($detail->produk->nama); ?></td>
                        <td align="center">Rp. <?php echo e(number_format($detail->produk->harga_jual)); ?></td>
                        <td align="center"><?php echo e($detail->qty); ?></td>
                        <td align="center">Rp. <?php echo e(number_format($detail->total)); ?></td>
                        <?php elseif($detail instanceof App\Models\PesananDetail): ?>
                        <td align="center"><?php echo e($detail->pesanan->no_order); ?></td>
                        <td align="center"><?php echo e($detail->produk->nama); ?></td>
                        <td align="center">Rp. <?php echo e(number_format($detail->produk->harga)); ?></td>
                        <td align="center"><?php echo e($detail->quantity); ?></td>
                        <td align="center">Rp. <?php echo e(number_format($detail->total_harga)); ?></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="7" align="center">Data tidak ditemukan</td>
                    </tr>
                    <?php endif; ?>
                </tbody>

            </table>
            <div class="d-flex justify-content-end">
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li class="page-item <?php echo e($mergedDetail->currentPage() == 1 ? 'disabled' : ''); ?>">
                            <a class="page-link" href="<?php echo e($mergedDetail->previousPageUrl()); ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <?php for($i = 1; $i <= $mergedDetail->lastPage(); $i++): ?>
                            <li class="page-item <?php echo e($mergedDetail->currentPage() == $i ? 'active' : ''); ?>">
                                <a class="page-link" href="<?php echo e($mergedDetail->url($i)); ?>"><?php echo e($i); ?></a>
                            </li>
                            <?php endfor; ?>
                            <li
                                class="page-item <?php echo e($mergedDetail->currentPage() == $mergedDetail->lastPage() ? 'disabled' : ''); ?>">
                                <a class="page-link" href="<?php echo e($mergedDetail->nextPageUrl()); ?>" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                    </ul>
                </nav>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views//admin-laporanpenjualan.blade.php ENDPATH**/ ?>