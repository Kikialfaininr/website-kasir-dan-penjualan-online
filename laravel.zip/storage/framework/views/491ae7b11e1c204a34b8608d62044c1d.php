<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Invoice Pesanan Online</title>
    <style>
    .container {
        width: 300px;
    }

    .header {
        margin: 0;
        text-align: center;
    }

    h2,
    p {
        margin: 0;
    }

    .flex-container-1 {
        display: flex;
        margin-top: 10px;
    }

    .flex-container-1>div {
        text-align: left;
    }

    .flex-container-1 .right {
        text-align: right;
        width: 200px;
    }

    .flex-container-1 .left {
        width: 100px;
    }

    .flex-container {
        width: 300px;
        display: flex;
    }

    .flex-container>div {
        -ms-flex: 1;
        /* IE 10 */
        flex: 1;
    }

    ul {
        display: contents;
    }

    ul li {
        display: block;
    }

    hr {
        border-style: dashed;
    }

    a {
        text-decoration: none;
        text-align: center;
        padding: 10px;
        background: #00e676;
        border-radius: 5px;
        color: white;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div class="container">
        <div class="header" style="margin-bottom: 30px;">
            <h2>Apotek Dua Farma</h2>
            <small>Jalan Jendral Sudirman No. 6A RT 01 RW 09 Planjan, Kecamatan Kesugihan, Kab. Cilacap, Provinsi Jawa
                Tengah
            </small>
        </div>
        <hr>
        <div class="flex-container-1">
            <div class="left">
                <ul>
                        <li>Username</li>
                        <li>No Order</li>
                        <li>Tanggal</li>
                        <li>Status</li>
                </ul>
            </div>
            <div class="right">
                <ul>
                    <li>
                        <?php if($pesanan->pelanggan): ?>
                        <?php echo e($pesanan->pelanggan->name); ?>

                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </li>
                    <li> <?php echo e($pesanan->no_order); ?> </li>
                    <li> <?php echo e(date('Y-m-d : H:i:s', strtotime($pesanan->created_at))); ?> </li>
                    <li>
                        <?php if($pesanan->status): ?>
                        <?php echo e($pesanan->status); ?>

                        <?php else: ?>
                        Belum Diproses
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="flex-container" style="margin-bottom: 10px; text-align:right;">
            <div style="text-align: left;">Nama Produk</div>
            <div>Harga/Qty</div>
            <div>Total</div>
        </div>
        <?php $__currentLoopData = $pesanan->PesananDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex-container" style="text-align: right;">
            <?php
            if(!empty($value->Produk->nama)) {
            $arr_name = explode(' ', $value->Produk->nama);
            $name = $arr_name[0];
            } elseif ($value->Produk->nama != '') {
            $name = $value->Produk->nama;
            } else {
            $name = 'there';
            }
            ?>
            <div style="text-align: left;"> <?php echo e($value->qty); ?>x <?php echo e($name); ?> </div>
            <div>Rp <?php echo e(number_format($value->Produk->harga_jual)); ?> </div>
            <div>Rp <?php echo e(number_format($value->total)); ?> </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="flex-container" style="text-align: right; margin-top: 10px;">
            <div></div>
            <div>
                <ul>
                    <li>Total</li>
                </ul>
            </div>
            <div style="text-align: right;">
                <ul>
                    <li>Rp <?php echo e(number_format($pesanan->grand_total)); ?> </li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="flex-container" style="margin-top: 10px;">
            <div>
                <ul>
                    <li>Pengiriman</li>
                </ul>
            </div>
            <div style="text-align: right;">
                <ul>
                    <li><?php echo e($pesanan->metode_pengiriman); ?> </li>
                </ul>
            </div>
        </div>
        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
        <div class="flex-container" style="text-align: right;">
            <div>
                <ul>
                    <li>Alamat</li>
                    <li>Wilayah</li>
                    <li>Ongkir</li>
                </ul>
            </div>
            <div style="text-align: right;">
                <ul>
                    <li><?php echo e($kirim->alamat); ?> </li>
                    <li><?php echo e($kirim->wilayah); ?> </li>
                    <li>Rp <?php echo e(number_format($kirim->ongkir)); ?> </li>
                </ul>
            </div>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
        <div class="flex-container" style="margin-top: 10px;">
            <div>
                <ul>
                    <li>Pembayaran</li>
                </ul>
            </div>
            <div style="text-align: right;">
                <ul>
                    <li><?php echo e($pesanan->metode_pembayaran); ?> </li>
                </ul>
            </div>
        </div>
        <div class="flex-container" style="text-align: right;">
            <div>
                <ul>
                    <li></li>
                </ul>
            </div>
            <?php $__currentLoopData = $buktiPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $bukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($bukti->id_pesanan == $value->id_pesanan): ?>
            <div style="text-align: right;">
                <ul>
                    <li><?php echo e($bukti->konfirmasi); ?></li>
                </ul>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr>
        <div class="flex-container" style="text-align: right; margin-top: 10px;">
            <div></div>
            <div>
                <ul>
                    <li><strong>Total Bayar</strong></li>
                </ul>
            </div>
            <?php
            $ongkir_tersedia = false;
            ?>

            <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
            <?php
            $ongkir_tersedia = true;
            ?>
            <div style="text-align: right;">
                <ul>
                    <li><strong>Rp <?php echo e(number_format($kirim->ongkir + $pesanan->grand_total)); ?> </strong></li>
                </ul>
            </div>
            <?php break; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!$ongkir_tersedia): ?>
            <div style="text-align: right;">
                <ul>
                    <li><strong>Rp <?php echo e(number_format($pesanan->grand_total)); ?> </strong></li>
                </ul>
            </div>
            <?php endif; ?>

        </div>
        <hr>
        <div class="header" style="margin-top: 20px;">
            <h3>Terimakasih</h3>
            <p>Silahkan melakukan pemesanan online kembali</p>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views/invoice-pesananonline.blade.php ENDPATH**/ ?>