


<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && (auth()->user()->level == 'apoteker')): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body d-flex align-items-center">
                    <form action="<?php echo e(url('kasir-riwayatpesananonline')); ?>" method="GET" class="w-100">
                        <div class="d-flex align-items-center">
                            <label for="tanggal" class="form-label me-2">Tanggal:</label>
                            <input type="date" class="form-control me-2" id="tanggal" name="tanggal">
                            <button type="submit" class="btn btn-primary">Cari</button>
                            <?php if(isset($tanggal)): ?>
                            <a href="<?php echo e(url('kasir-riwayatpesananonline')); ?>" class="btn btn-secondary ms-2">All</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="row justify-content-center mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="invoice-tab" data-bs-toggle="tab"
                                data-bs-target="#invoice" type="button" role="tab" aria-controls="invoice"
                                aria-selected="true">Invoice Penjualan</button>
                            <button class="nav-link" id="produkterjual-tab" data-bs-toggle="tab"
                                data-bs-target="#produkterjual" type="button" role="tab" aria-controls="produkterjual"
                                aria-selected="false">Produk Terjual</button>
                        </div>
                    </nav>

                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="invoice" role="tabpanel"
                            aria-labelledby="invoice-tab" tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Pesanan Online</h3>
                            <?php if(isset($tanggal)): ?>
                            <p style="color: #B4B4B8; text-align: center;">Tanggal: <?php echo e($tanggal); ?></p>
                            <?php endif; ?>
                            <div class="col-md-8" style="margin-bottom: 10px;">
                                <a href="<?php echo e(url('download-riwayatpesanan')); ?>" target="_blank">
                                    <button class="btn btn-danger">
                                        <i class='fas fa-file-pdf'></i> Cetak
                                    </button>
                                </a>
                            </div>
                            <div class="table-responsive">
                                <table id="example1" class="table table-responsive table-striped table-hover table-bordered small">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">Username</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Pengiriman</th>
                                            <th class="text-center">Pembayaran</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 0 ?>
                                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->status == 'Selesai'): ?>
                                        <tr>
                                            <td align="center"><?php echo e(++$no); ?></td>
                                            <td align="center"><?php echo e($value->updated_at); ?></td>
                                            <td align="center">
                                                <?php if($value->pelanggan): ?>
                                                    <?php echo e($value->pelanggan->name); ?>

                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td align="center"><?php echo e($value->no_order); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->grand_total)); ?></td>
                                            <td align="center"><?php echo e($value->metode_pengiriman); ?> </td>
                                            <td align="center"><?php echo e($value->metode_pembayaran); ?> </td>
                                            <td align="center" style="background-color: green; color: white;">
                                                <?php echo e($value->status); ?></td>
                                            <td align="center">
                                                <button type="button" class="btn btn-primary btn-sm"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#detail<?php echo e($value->id_pesanan); ?>"
                                                    title="Detail Pesanan"
                                                    style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
                                                    Detail
                                                </button>
                                                <a href="<?php echo e(url($value->id_pesanan.'/invoice-pesananonline')); ?>"
                                                    target="_blank">
                                                    <button class="btn btn-danger btn-sm" style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem;">
                                                        <i class="fas fa-file-invoice"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="produkterjual" role="tabpanel" aria-labelledby="produkterjual-tab" tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Produk Terjual</h3>
                            <?php if(isset($tanggal)): ?>
                            <p style="color: #B4B4B8; text-align: center;">Tanggal: <?php echo e($tanggal); ?></p>
                            <?php endif; ?>
                            <div class="col-md-8" style="margin-bottom: 10px;">
                                <a href="<?php echo e(url('download-riwayatdetail')); ?>" target="_blank">
                                    <button class="btn btn-danger">
                                        <i class='fas fa-file-pdf'></i> Cetak
                                    </button>
                                </a>
                            </div>
                            <div class="table-responsive">
                                <table id="example2" class="table table-responsive table-striped table-hover table-bordered small" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Produk</th>
                                            <th class="text-center">Harga</th>
                                            <th class="text-center">QTY</th>
                                            <th class="text-center">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $no = 0 ?>
                                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->pesanan->status == 'Selesai'): ?>
                                        <tr>
                                            <td align="center"><?php echo e(++$no); ?></td>
                                            <td align="center"><?php echo e($value->updated_at); ?></td>
                                            <td align="center"><?php echo e($value->pesanan->no_order); ?></td>
                                            <td align="center"><?php echo e($value->produk->nama); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->produk->harga_jual)); ?></td>
                                            <td align="center"><?php echo e($value->qty); ?> </td>
                                            <td align="center">Rp <?php echo e(number_format($value->total)); ?> </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal" id="detail<?php echo e($value->id_pesanan); ?>" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Detail Pesanan</h4>
            </div>
            <div class="modal-body">
                <table class="table table-responsive table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Produk</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">QTY</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = 0;
                        $last_order_id = null;
                        ?>

                        <?php $__currentLoopData = $pesananDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->id_pesanan != $last_order_id): ?>
                        <?php
                        $counter = 1;
                        $last_order_id = $detail->id_pesanan;
                        ?>
                        <?php endif; ?>

                        <?php if($detail->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td align="center"><?php echo e($counter); ?></td>
                            <td align="center"><?php echo e($detail->produk->nama); ?></td>
                            <td align="center">Rp. <?php echo e(number_format($detail->produk->harga_jual)); ?></td>
                            <td align="center"><?php echo e($detail->qty); ?></td>
                            <td align="center">Rp. <?php echo e(number_format($detail->total)); ?></td>
                        </tr>
                        <?php $counter++; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Pengiriman</strong></td>
                            <td style="background-color: #EEEEEE"><strong><?php echo e($value->metode_pengiriman); ?></strong>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2">Alamat</td>
                            <td><?php echo e($kirim->alamat); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="2">Wilayah</td>
                            <td><?php echo e($kirim->wilayah); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2">Ongkir</td>
                            <td><?php echo e($kirim->ongkir); ?> </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Pembayaran</strong></td>
                            <td style="background-color: #EEEEEE"><strong><?php echo e($value->metode_pembayaran); ?></strong>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $buktiPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $bukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($bukti->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2">Bukti Pembayaran</td>
                            <td><a href="images/buktipembayaran/<?php echo e($bukti->foto); ?>" target="_blank"><img
                                        src="images/buktipembayaran/<?php echo e($bukti->foto); ?>" width="100px"></a></td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td>
                                <?php if($bukti->konfirmasi == 'Terkonfirmasi'): ?>
                                <strong><i class="fa fa-check"></i> Terkonfirmasi</strong>
                                <?php else: ?>
                                <form action="<?php echo e(url('konfirmasi-pembayaran')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="bukti_pembayaran_id" value="<?php echo e($bukti->id_bukti); ?>">
                                    <button type="submit" class="btn btn-warning">Konfirmasi Pembayaran</button>
                                </form>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Total Pembayaran</strong></td>
                            <td style="background-color: #EEEEEE"><strong>Rp
                                    <?php echo e(number_format($kirim->ongkir + $value->grand_total)); ?></strong>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#example1', {
    responsive: true,
    rowReorder: {
        selector: 'td:nth-child(2)'
    }
});
</script>
<script>
    new DataTable('#example2', {
    responsive: true,
    rowReorder: {
        selector: 'td:nth-child(2)'
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php else: ?>
<?php abort(403, 'Unauthorized action.'); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-kasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views//kasir-riwayatpesananonline.blade.php ENDPATH**/ ?>