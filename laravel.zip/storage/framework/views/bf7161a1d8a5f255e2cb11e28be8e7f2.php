


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body d-flex align-items-center">
                    <form action="<?php echo e(url('kasir-riwayat')); ?>" method="GET" class="w-100">
                        <div class="d-flex align-items-center">
                            <label for="tanggal" class="form-label me-2">Tanggal:</label>
                            <input type="date" class="form-control me-2" id="tanggal" name="tanggal">
                            <button type="submit" class="btn btn-primary">Cari</button>
                            <?php if(isset($tanggal)): ?>
                            <a href="<?php echo e(url('kasir-riwayat')); ?>" class="btn btn-secondary ms-2">All</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <div class="row justify-content-center mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="invoice-tab" data-bs-toggle="tab"
                                data-bs-target="#invoice" type="button" role="tab" aria-controls="invoice"
                                aria-selected="true">Invoice Penjualan</button>
                            <button class="nav-link" id="produkterjual-tab" data-bs-toggle="tab"
                                data-bs-target="#produkterjual" type="button" role="tab" aria-controls="produkterjual"
                                aria-selected="false">Produk Terjual</button>
                        </div>
                    </nav>

                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="invoice" role="tabpanel"
                            aria-labelledby="invoice-tab" tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Invoice Penjualan</h3>
                            <?php if(isset($tanggal)): ?>
                            <p style="color: #B4B4B8; text-align: center;">Tanggal: <?php echo e($tanggal); ?></p>
                            <?php endif; ?>
                            <div class="col-md-8" style="margin-bottom: 10px;">
                                <a href="<?php echo e(url('downloadinvoice')); ?>" target="_blank">
                                    <button class="btn btn-danger">
                                        <i class="fa fa-file-pdf-o"></i> Cetak
                                    </button>
                                </a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-responsive table-striped table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Kasir</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Pembayaran</th>
                                            <th class="text-center">Kembalian</th>
                                            <th class="text-center">Metode Pembayaran</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($penjualan) && count($penjualan) > 0): ?>
                                        <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td align="center"><?php echo e($no+1); ?></td>
                                            <td align="center"><?php echo e($value->created_at); ?></td>
                                            <td align="center"><?php echo e($value->no_order); ?></td>
                                            <td align="center"><?php echo e($value->nama_kasir); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->grand_total)); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->pembayaran)); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->kembalian)); ?></td>
                                            <td align="center"><?php echo e($value->metode_pembayaran); ?> </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="12" align="center">Data tidak ditemukan</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php if(isset($penjualan) && count($penjualan) > 0): ?>
                            <div class="d-flex justify-content-end">
                                <nav aria-label="Page navigation">
                                    <ul class="pagination">
                                        <li class="page-item <?php echo e($penjualan->currentPage() == 1 ? 'disabled' : ''); ?>">
                                            <a class="page-link" href="<?php echo e($penjualan->previousPageUrl()); ?>"
                                                aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                        <?php for($i = 1; $i <= $penjualan->lastPage(); $i++): ?>
                                            <li class="page-item <?php echo e($penjualan->currentPage() == $i ? 'active' : ''); ?>">
                                                <a class="page-link" href="<?php echo e($penjualan->url($i)); ?>"><?php echo e($i); ?></a>
                                            </li>
                                            <?php endfor; ?>
                                            <li
                                                class="page-item <?php echo e($penjualan->currentPage() == $penjualan->lastPage() ? 'disabled' : ''); ?>">
                                                <a class="page-link" href="<?php echo e($penjualan->nextPageUrl()); ?>"
                                                    aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                </a>
                                            </li>
                                    </ul>
                                </nav>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="produkterjual" role="tabpanel"
                            aria-labelledby="produkterjual-tab" tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Produk Terjual</h3>
                            <?php if(isset($tanggal)): ?>
                            <p style="color: #B4B4B8; text-align: center;">Tanggal: <?php echo e($tanggal); ?></p>
                            <?php endif; ?>
                            <div class="col-md-8" style="margin-bottom: 10px;">
                                <a href="<?php echo e(url('downloadprodukterjual')); ?>" target="_blank">
                                    <button class="btn btn-danger">
                                        <i class="fa fa-file-pdf-o"></i> Cetak
                                    </button>
                                </a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-responsive table-striped table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Produk</th>
                                            <th class="text-center">Harga</th>
                                            <th class="text-center">QTY</th>
                                            <th class="text-center">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(isset($penjualanDetail) && count($penjualanDetail) > 0): ?>
                                        <?php $__currentLoopData = $penjualanDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td align="center"><?php echo e($no+1); ?></td>
                                            <td align="center"><?php echo e($value->created_at); ?></td>
                                            <td align="center"><?php echo e($value->penjualan->no_order); ?></td>
                                            <td align="center"><?php echo e($value->produk->nama); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->produk->harga_jual)); ?></td>
                                            <td align="center"><?php echo e($value->qty); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->total)); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="12" align="center">Data tidak ditemukan</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php if(isset($penjualanDetail) && count($penjualanDetail) > 0): ?>
                            <div class="d-flex justify-content-end">
                                <nav aria-label="Page navigation">
                                    <ul class="pagination">
                                        <li class="page-item <?php echo e($penjualanDetail->currentPage() == 1 ? 'disabled' : ''); ?>">
                                            <a class="page-link" href="<?php echo e($penjualanDetail->previousPageUrl()); ?>"
                                                aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>
                                        <?php for($i = 1; $i <= $penjualanDetail->lastPage(); $i++): ?>
                                            <li
                                                class="page-item <?php echo e($penjualanDetail->currentPage() == $i ? 'active' : ''); ?>">
                                                <a class="page-link" href="<?php echo e($penjualanDetail->url($i)); ?>"><?php echo e($i); ?></a>
                                            </li>
                                            <?php endfor; ?>
                                            <li
                                                class="page-item <?php echo e($penjualanDetail->currentPage() == $penjualanDetail->lastPage() ? 'disabled' : ''); ?>">
                                                <a class="page-link" href="<?php echo e($penjualanDetail->nextPageUrl()); ?>"
                                                    aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                </a>
                                            </li>
                                    </ul>
                                </nav>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-kasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views//kasir-riwayat.blade.php ENDPATH**/ ?>