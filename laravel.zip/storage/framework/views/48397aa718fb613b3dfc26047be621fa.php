<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\apotek\sistem\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>