


<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && (auth()->user()->level == 'admin' || auth()->user()->level == 'owner')): ?>
<div class="card card-data col-md-12">
    <h1 style="color: #34495e; margin: 30px 0 30px 0; font-weight: bold; text-align: center;">Pesanan Online Selesai
        Diproses</h1>
    <?php if(isset($tanggal)): ?>
    <p style="color: #B4B4B8; text-align: center;">Tanggal: <?php echo e($tanggal); ?></p>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12 col-xs-12">
            <div class="row" style="margin: 10px;">
                <div class="col-md-8">
                    <a href="<?php echo e(url('downloadpesanan')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak Pesanan Online
                        </button>
                    </a>
                    <a href="<?php echo e(url('downloadpesanandetail')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak Produk Online Terjual
                        </button>
                    </a>
                </div>
                <div class="col-md-4">
                    <form action="<?php echo e(url('admin-pesananselesai')); ?>" method="GET" class="w-100">
                        <div class="d-flex align-items-center">
                            <input type="date" class="form-control me-2" id="tanggal" name="tanggal">
                            <button type="submit" class="btn btn-primary">Cari</button>
                            <?php if(isset($tanggal)): ?>
                            <a href="<?php echo e(url('admin-pesananselesai')); ?>" class="btn btn-secondary ms-2">All</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="table-responsive" style="width: 97%; margin-left: 15px;">
            <table id="example" class="table table-responsive table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">Waktu</th>
                        <th class="text-center">Username</th>
                        <th class="text-center">No Order</th>
                        <th class="text-center">Total</th>
                        <th class="text-center">Pengiriman</th>
                        <th class="text-center">Pembayaran</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 0 ?>
                    <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($value->status == 'Selesai'): ?>
                    <tr>
                        <td align="center"><?php echo e(++$no); ?></td>
                        <td align="center"><?php echo e($value->updated_at); ?></td>
                        <td align="center">
                            <?php if($value->pelanggan): ?>
                            <?php echo e($value->pelanggan->name); ?>

                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>
                        <td align="center"><?php echo e($value->no_order); ?></td>
                        <td align="center">Rp. <?php echo e(number_format($value->grand_total)); ?></td>
                        <td align="center"><?php echo e($value->metode_pengiriman); ?> </td>
                        <td align="center"><?php echo e($value->metode_pembayaran); ?> </td>
                        <td align="center" style="background-color: green; color: white;"><?php echo e($value->status); ?></td>
                        <td align="center">
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                data-bs-target="#detail<?php echo e($value->id_pesanan); ?>" title="Detail Pesanan">
                                Detail
                            </button>
                            <a href="<?php echo e(url($value->id_pesanan.'/invoice-pesananonline')); ?>" target="_blank">
                                <button class="btn btn-danger btn-sm">
                                    <i class="fas fa-file-invoice"></i>
                                </button>
                            </a>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal" id="detail<?php echo e($value->id_pesanan); ?>" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Detail Pesanan</h4>
            </div>
            <div class="modal-body">
                <table class="table table-responsive table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Produk</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">QTY</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = 0;
                        $last_order_id = null;
                        ?>

                        <?php $__currentLoopData = $pesananDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->id_pesanan != $last_order_id): ?>
                        <?php
                        $counter = 1;
                        $last_order_id = $detail->id_pesanan;
                        ?>
                        <?php endif; ?>

                        <?php if($detail->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td align="center"><?php echo e($counter); ?></td>
                            <td align="center"><?php echo e($detail->produk->nama); ?></td>
                            <td align="center">Rp. <?php echo e(number_format($detail->produk->harga_jual)); ?></td>
                            <td align="center"><?php echo e($detail->qty); ?></td>
                            <td align="center">Rp. <?php echo e(number_format($detail->total)); ?></td>
                        </tr>
                        <?php $counter++; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Pengiriman</strong></td>
                            <td style="background-color: #EEEEEE"><strong><?php echo e($value->metode_pengiriman); ?></strong>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2">Alamat</td>
                            <td><?php echo e($kirim->alamat); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="2">Wilayah</td>
                            <td><?php echo e($kirim->wilayah); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2">Ongkir</td>
                            <td><?php echo e($kirim->ongkir); ?> </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Pembayaran</strong></td>
                            <td style="background-color: #EEEEEE"><strong><?php echo e($value->metode_pembayaran); ?></strong>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $buktiPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $bukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($bukti->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2">Bukti Pembayaran</td>
                            <td><a href="images/buktipembayaran/<?php echo e($bukti->foto); ?>" target="_blank"><img
                                        src="images/buktipembayaran/<?php echo e($bukti->foto); ?>" width="100px"></a></td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td>
                                <?php if($bukti->konfirmasi == 'Terkonfirmasi'): ?>
                                <strong><i class="fa fa-check"></i> Terkonfirmasi</strong>
                                <?php else: ?>
                                <form action="<?php echo e(url('konfirmasi-pembayaran')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="bukti_pembayaran_id" value="<?php echo e($bukti->id_bukti); ?>">
                                    <button type="submit" class="btn btn-warning">Konfirmasi Pembayaran</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Total Pembayaran</strong></td>
                            <td style="background-color: #EEEEEE"><strong>Rp
                                    <?php echo e(number_format($kirim->ongkir + $value->grand_total)); ?></strong>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php $__currentLoopData = $buktiPenerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $penerimaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($penerimaan->id_pesanan == $value->id_pesanan): ?>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="3" style="background-color: #EEEEEE;">
                                <strong>Bukti Penerimaan Pelanggan</strong>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">Bukti Penerimaan</td>
                            <td><a href="images/buktipenerimaan/<?php echo e($penerimaan->foto); ?>" target="_blank">
                                    <img src="images/buktipenerimaan/<?php echo e($penerimaan->foto); ?>" width="100px"></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#example', {
    responsive: true,
    rowReorder: {
        selector: 'td:nth-child(2)'
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php else: ?>
<?php abort(403, 'Unauthorized action.'); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views//admin-pesananselesai.blade.php ENDPATH**/ ?>