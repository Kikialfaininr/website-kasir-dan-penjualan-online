


<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && (auth()->user()->level == 'admin' || auth()->user()->level == 'owner')): ?>
<div class="card card-data col-md-12">
    <h1 style="color: #34495e; margin: 30px 0 30px 0; font-weight: bold; text-align: center;">Laporan Stok Opname</h1>
    <div class="row">
        <div class="col-md-12 col-xs-12">
            <div class="row" style="margin: 0 10px 10px 10px;">
                <div class="col-md-8">
                    <a href="<?php echo e(url('download-laporanstok')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak Stok Opname
                        </button>
                    </a>
                    <a href="<?php echo e(url('downloadstokmenipis')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak Stok Menipis
                        </button>
                    </a>
                    <a href="<?php echo e(url('downloadstokhabis')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak Stok Habis
                        </button>
                    </a>
                </div>
            </div>
        </div>

        <div class="table-responsive" style="width: 97%; margin-left: 15px;">
            <table id="example" class="table table-responsive table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">Nama Produk</th>
                        <th class="text-center">Bentuk Sediaan</th>
                        <th class="text-center">Satuan</th>
                        <th class="text-center">Stok</th>
                        <th class="text-center">Harga Beli</th>
                        <th class="text-center">Kategori</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $counter = 0;
                    ?>
                    <?php if(isset($produk) && count($produk) > 0): ?>
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $counter++; ?>
                    <tr>
                        <td align="center"><?php echo e($counter); ?></td>
                        <td><?php echo e($value->nama); ?></td>
                        <td><?php echo e($value->bentuk_sediaan); ?></td>
                        <td><?php echo e($value->satuan); ?></td>
                        <td align="center"><?php echo e($value->stok); ?></td>
                        <td align="center">Rp <?php echo e(number_format($value->harga_beli)); ?></td>
                        <td><?php echo e($value->kategori->nama_kategori); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#example', {
    responsive: true,
    rowReorder: {
        selector: 'td:nth-child(2)'
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php else: ?>
<?php abort(403, 'Unauthorized action.'); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views/admin-laporanstok.blade.php ENDPATH**/ ?>