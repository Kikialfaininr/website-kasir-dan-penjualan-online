<?php if(Session::has('sukses')): ?>
<div class="col-md-6">
    <div id="alert" class="alert alert-success" style="width:300px; right:36px; top:60px; cursor:auto; opacity:1; position:fixed; z-index: 1060;">
        <span class="fa fa-check"></span> <strong>Sukses</strong>
        <button type="button" class="btn-close btn-close-white" data-dismiss="alert" aria-label="Close" style="position: absolute; top: 0; right: 0;"></button>
        <hr class="messege-inner-seperator">
        <p><?php echo e(Session::get('sukses')); ?></p>
    </div>
</div>
<?php elseif(Session::has('gagal')): ?>
<div class="col-md-6">
    <div id="alert" class="alert alert-danger" style="width:300px; right:36px; top:60px; cursor:auto; opacity:1; position:fixed; z-index: 1060;">
        <span class="fa fa-times"></span> <strong>Gagal</strong>
        <button type="button" class="btn-close btn-close-white" data-dismiss="alert" aria-label="Close" style="position: absolute; top: 0; right: 0;"></button>
        <hr class="messege-inner-seperator">
        <p><?php echo e(Session::get('gagal')); ?></p>
    </div>
</div>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views/layouts/alert.blade.php ENDPATH**/ ?>