


<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && (auth()->user()->level == 'apoteker')): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="form-group row pb-5">
                        <form method="POST" action="<?php echo e(url('tambah-transaksi')); ?>" class="row g-3 mt-3">
                            <?php echo csrf_field(); ?>
                            <label for="produk" class="col-sm-2 col-form-label">Produk</label>
                            <div class="col-sm-8">
                                <select class="form-control select2 <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="id_produk" required>
                                    <option>-- Pilih Produk --</option>
                                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($produk->id_produk); ?>"><?php echo e($produk->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                <script>
                                $(document).ready(function() {
                                    $('.select2').select2();
                                });
                                </script>

                                <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="validationServer03Feedback" class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-sm-2">
                                <button type="submit" class="btn btn-success w-100">Tambah</button>
                            </div>
                        </form>
                    </div>

                    <?php if(session()->has('message')): ?>
                    <?php
                    $alertClass = session('alert_class', 'success');
                    ?>

                    <div class="alert alert-<?php echo e($alertClass); ?>">
                        <?php echo e(session('message')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="card-body border-top pb-5 p-0 mt-3">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">No</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">QTY</th>
                                    <th scope="col">Harga/QTY</th>
                                    <th scope="col" style="width: 200px;">Total</th>
                                    <th scope="col" style="width: 10px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $kasir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td align="center"><?php echo e($no+1); ?></td>
                                    <td><?php echo e($value->produk->nama); ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <?php if($value->qty > 1): ?>
                                            <a href="<?php echo e(url('/change-quantity?id_produk=' . $value->id_produk . '&act=minus')); ?>"
                                                class="btn btn-primary"><i class="fas fa-minus"></i></a>
                                            <?php endif; ?>
                                            <input type="number" value="<?php echo e($value->qty); ?>" class="form-control"
                                                name="qty" id="qty-<?php echo e($value->id_produk); ?>" readonly
                                                style="text-align: center;">
                                            <a href="<?php echo e(url('/change-quantity?id_produk=' . $value->id_produk . '&act=plus')); ?>"
                                                class="btn btn-primary"><i class="fas fa-plus"></i></a>
                                        </div>
                                    </td>
                                    <td>Rp. <?php echo e(number_format($value->produk->harga_jual)); ?></td>
                                    <td>Rp. <?php echo e(number_format($value->produk->harga_jual*$value->qty)); ?></td>
                                    <td>
                                        <a href="<?php echo e(url($value->id_kasir.'/hapus-kasir')); ?>">
                                            <button title="Hapus Data" class="btn btn-danger btn-sm"><i
                                                    class="fas fa-trash"></i></button>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <form method="POST" action="<?php echo e(url('simpan-transaksi')); ?>" target="_blank">
                                <?php echo csrf_field(); ?>
                                <tfoot>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td style="text-align:right;">Total Pembelian</td>
                                    <td>
                                        Rp <?php echo e(number_format($kasir->sum('total'))); ?>

                                    </td>
                                    <tr>
                                        <td style="border:none;"></td>
                                        <td style="border:none;"></td>
                                        <td style="border:none;"></td>
                                        <td style="text-align:right;">Pembayaran</td>
                                        <td style="text-align:right;">
                                            <input type="number" id="pembayaran" class="form-control" name="pembayaran"
                                                oninput="hitungKembalian()">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="border:none;"></td>
                                        <td style="border:none;"></td>
                                        <td style="border:none;"></td>
                                        <td style="text-align:right;">Kembalian</td>
                                        <td id="kembalian" style="text-align:left;">Rp </td>
                                    </tr>
                                    <tr>
                                        <td style="border:none;"></td>
                                        <td style="border:none;"></td>
                                        <td style="border:none;"></td>
                                        <td style="text-align:right;">Metode Pembayaran</td>
                                        <td style="text-align:center;">
                                            <label><input type="radio" name="metode_pembayaran" value="Tunai" checked>
                                                Tunai</label>
                                            <label><input type="radio" name="metode_pembayaran" value="QRIS">
                                                QRIS</label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="border:none;"></td>
                                    </tr>
                                    <tr>
                                        <td colspan="5" style="border:none;">
                                            <button type="submit" class="btn btn-success btn-sm float-right"
                                                style="width: 100%;">Simpan</button>
                                        </td>
                                    </tr>
                                </tfoot>
                            </form>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function hitungKembalian() {
    var pembayaran = parseInt(document.getElementById('pembayaran').value);
    console.log('Nilai Pembayaran:', pembayaran);

    var totalPembelian = parseInt(<?php echo $kasir->sum('total'); ?>);

    console.log('Total Pembelian:', totalPembelian);

    var kembalian = pembayaran - totalPembelian;
    console.log('Kembalian:', kembalian);

    document.getElementById('kembalian').innerHTML = 'Rp ' + kembalian.toLocaleString('id-ID');
}
</script>

<?php else: ?>
<?php abort(403, 'Unauthorized action.'); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-kasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/kasir.blade.php ENDPATH**/ ?>