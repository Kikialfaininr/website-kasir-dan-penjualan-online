


<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && (auth()->user()->level == 'admin' || auth()->user()->level == 'owner')): ?>
<div class="card card-data col-md-12">
    <h1 style="color: #34495e; margin: 30px 0 30px 0; font-weight: bold; text-align: center;">Data Ongkos Kirim</h1>
    <div class="row">
        <div class="col-md-12 col-xs-12">
            <div style="margin: 0 20px 0 20px;">
                <?php if(session()->has('message')): ?>
                <?php
                $alertClass = session('alert_class', 'success');
                ?>

                <div class="alert alert-<?php echo e($alertClass); ?>">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>

                <?php if(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="row">
                <?php if(auth()->check() && (auth()->user()->level == 'admin')): ?>
                <div class="col-md-8">
                    <button type="button" style="margin: 20px 0 20px 20px;" class="btn btn-primary"
                        data-bs-toggle="modal" data-bs-target="#TambahDataOngkir" title="Tambah Data">
                        <i class="fa fa-plus"></i> Tambah Data Ongkir
                    </button>
                    <a href="<?php echo e(url('downloadpdf-ongkir')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak
                        </button>
                    </a>
                </div>
                <?php else: ?>
                <div class="col-md-8">
                    <a style="margin: 20px;" href="<?php echo e(url('downloadpdf-ongkir')); ?>" target="_blank">
                        <button class="btn btn-danger">
                            <i class='fas fa-file-pdf'></i> Cetak
                        </button>
                    </a>
                </div>
                <div class="col-md-4">
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="table-responsive" style="width: 97%; margin-left: 15px;">
            <table id="example" class="table table-responsive table-striped table-hover table-bordered">
                <thead>
                    <tr>
                        <th class="text-center">No</th>
                        <th class="text-center">wilayah</th>
                        <th class="text-center">Ongkir</th>
                        <?php if(auth()->check() && (auth()->user()->level == 'admin')): ?>
                        <th class="text-center">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ongkir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td align="center"><?php echo e($no+1); ?></td>
                        <td align="center"><?php echo e($value->wilayah); ?></td>
                        <td align="center">Rp <?php echo e(number_format($value->ongkir)); ?></td>
                        <?php if(auth()->check() && (auth()->user()->level == 'admin')): ?>
                        <td align="center">
                            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                data-bs-target="#UbahOngkir<?php echo e($value->id_ongkir); ?>" title="Tambah Data">
                                <i class="fa fa-edit"></i>
                            </button>
                            <a href="<?php echo e(url($value->id_ongkir.'/hapus-ongkir')); ?>">
                                <button title="Hapus Data" class="btn btn-danger btn-sm"><i
                                        class="fas fa-trash"></i></button>
                            </a>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal" id="TambahDataOngkir" role="dialog">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Tambah Data Ongkir</h4>
            </div>
            <div class="modal-body">
                <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(url('simpan-data-ongkir')); ?>">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="wilayah"><?php echo e(__('Wilayah')); ?></label>
                        <div class="input-group">
                            <input id="wilayah" type="text" class="form-control <?php $__errorArgs = ['wilayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="wilayah" value="<?php echo e(old('wilayah')); ?>" required autofocus>
                        </div>
                        <?php $__errorArgs = ['wilayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="ongkir"><?php echo e(__('Ongkir')); ?></label>
                        <input id="ongkir" type="text" class="form-control <?php $__errorArgs = ['ongkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ongkir" value="<?php echo e(old('ongkir')); ?>" required autofocus>
                        <?php $__errorArgs = ['ongkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label text-md-end"></label>
                        <div class="col-md-8">
                            <button class="btn btn-success">Simpan</button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__currentLoopData = $ongkir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal" id="UbahOngkir<?php echo e($value->id_ongkir); ?>" role="dialog">
    <div class="modal-dialog modal-xs">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Ubah Data Ongkir</h4>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(url('update-ongkir/'.$value->id_ongkir)); ?>">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="wilayah"><?php echo e(__('Wilayah')); ?></label>
                        <div class="input-group">
                            <input id="wilayah" type="text" class="form-control <?php $__errorArgs = ['wilayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="wilayah" value="<?php echo e($value->wilayah); ?>" required autofocus>
                        </div>
                        <?php $__errorArgs = ['wilayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label for="ongkir"><?php echo e(__('Ongkir')); ?></label>
                        <input id="ongkir" type="text" class="form-control <?php $__errorArgs = ['ongkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="ongkir" value="<?php echo e($value->ongkir); ?>" required autofocus>
                        <?php $__errorArgs = ['ongkir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label text-md-end"></label>
                        <div class="col-md-8">
                            <button class="btn btn-success">Simpan</button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
new DataTable('#example', {
    responsive: true,
    rowReorder: {
        selector: 'td:nth-child(2)'
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php else: ?>
<?php abort(403, 'Unauthorized action.'); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views/admin-Ongkir.blade.php ENDPATH**/ ?>