


<?php $__env->startSection('content'); ?>
<?php if(auth()->check() && (auth()->user()->level == 'apoteker')): ?>
<div class="container">
    <div class="row justify-content-center mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                <div class="row">
                        <div class="col-md-8">
                            <a href="<?php echo e(url('download-laporanstok')); ?>" target="_blank">
                                <button class="btn btn-danger">
                                    <i class='fas fa-file-pdf'></i> Cetak
                                </button>
                            </a>
                        </div>
                        <div class="col-md-4">
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="example" class="table table-responsive table-striped table-hover table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Nama Produk</th>
                                    <th class="text-center">Bentuk Sediaan</th>
                                    <th class="text-center">Satuan</th>
                                    <th class="text-center">Stok</th>
                                    <th class="text-center">Harga Beli</th>
                                    <th class="text-center">Harga Jual</th>
                                    <th class="text-center">Kategori</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $counter = 0;
                                ?>
                                <?php if(isset($produk) && count($produk) > 0): ?>
                                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $counter++; ?>
                                <tr>
                                    <td align="center"><?php echo e($counter); ?></td>
                                    <td><?php echo e($value->nama); ?></td>
                                    <td><?php echo e($value->bentuk_sediaan); ?></td>
                                    <td><?php echo e($value->satuan); ?></td>
                                    <td align="center"><?php echo e($value->stok); ?></td>
                                    <td align="center">Rp <?php echo e(number_format($value->harga_beli)); ?></td>
                                    <td align="center">Rp <?php echo e(number_format($value->harga_jual)); ?></td>
                                    <td><?php echo e($value->kategori->nama_kategori); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    new DataTable('#example', {
    responsive: true,
    rowReorder: {
        selector: 'td:nth-child(2)'
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php else: ?>
<?php abort(403, 'Unauthorized action.'); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-kasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views/kasir-stokproduk.blade.php ENDPATH**/ ?>