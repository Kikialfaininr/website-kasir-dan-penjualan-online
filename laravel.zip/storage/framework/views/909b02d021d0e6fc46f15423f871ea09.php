


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">

                        </div>
                        <div class="col-md-4">
                            <form action="<?php echo e(url('admin-pesananmasuk')); ?>" method="GET" class="w-100">
                                <div class="d-flex align-items-center">
                                    <input type="date" class="form-control me-2" id="tanggal" name="tanggal">
                                    <button type="submit" class="btn btn-primary">Cari</button>
                                    <?php if(isset($tanggal)): ?>
                                    <a href="<?php echo e(url('admin-pesananmasuk')); ?>" class="btn btn-secondary ms-2">All</a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row justify-content-center mt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <nav>
                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                            <button class="nav-link active" id="diproses-tab" data-bs-toggle="tab"
                                data-bs-target="#diproses" type="button" role="tab" aria-controls="diproses"
                                aria-selected="true">Diproses</button>
                            <button class="nav-link" id="siap-tab" data-bs-toggle="tab" data-bs-target="#siap"
                                type="button" role="tab" aria-controls="siap" aria-selected="true">Siap</button>
                            <button class="nav-link" id="siap-tab" data-bs-toggle="tab" data-bs-target="#dikirim"
                                type="button" role="tab" aria-controls="siap" aria-selected="true">Dikirim</button>
                        </div>
                    </nav>

                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="diproses" role="tabpanel"
                            aria-labelledby="diproses-tab" tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Pesanan Diproses</h3>
                            <div class="table-responsive" style="margin-top: 20px;">
                                <table class="table table-responsive table-striped table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Pengiriman</th>
                                            <th class="text-center">Pembayaran</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 0;
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <?php if(is_null($value->status)): ?>
                                        <?php
                                        $no++;
                                        ?>
                                        <tr>
                                            <td align="center"><?php echo e($no+1); ?></td>
                                            <td align="center"><?php echo e($value->created_at); ?></td>
                                            <td align="center"><?php echo e($value->no_order); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->grand_total)); ?></td>
                                            <td align="center"><?php echo e($value->metode_pengiriman); ?> </td>
                                            <td align="center"><?php echo e($value->metode_pembayaran); ?> </td>
                                            <td align="center" style="<?php if($value->status == 'Ditolak'): ?> background-color: red;
                                                    <?php elseif($value->status == 'Siap'): ?> background-color: blue;
                                                    <?php elseif($value->status == 'Dikirim'): ?> background-color: gray;
                                                    <?php elseif($value->status == 'Selesai'): ?> background-color: green;
                                                    <?php elseif(is_null($value->status)): ?> background-color: #FFC700;
                                                    <?php endif; ?>; color: white;">
                                                <?php if(is_null($value->status)): ?>
                                                Belum Diproses
                                                <?php else: ?>
                                                <?php echo e($value->status); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td align="center">
                                                <button type="button" class="btn btn-primary btn-sm"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#detail<?php echo e($value->id_pesanan); ?>"
                                                    title="Detail Pesanan">
                                                    Detail
                                                </button>
                                                <a href="<?php echo e(url($value->id_pesanan.'/invoice-pesananonline')); ?>"
                                                    target="_blank">
                                                    <button class="btn btn-danger btn-sm">
                                                        <i class="fas fa-file-invoice"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="12" align="center">Data tidak ditemukan</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end">
                                    <nav aria-label="Page navigation">
                                        <ul class="pagination">
                                            <li class="page-item <?php echo e($pesanan->currentPage() == 1 ? 'disabled' : ''); ?>">
                                                <a class="page-link" href="<?php echo e($pesanan->previousPageUrl()); ?>"
                                                    aria-label="Previous">
                                                    <span aria-hidden="true">&laquo;</span>
                                                </a>
                                            </li>
                                            <?php for($i = 1; $i <= $pesanan->lastPage(); $i++): ?>
                                                <li
                                                    class="page-item <?php echo e($pesanan->currentPage() == $i ? 'active' : ''); ?>">
                                                    <a class="page-link" href="<?php echo e($pesanan->url($i)); ?>"><?php echo e($i); ?></a>
                                                </li>
                                                <?php endfor; ?>
                                                <li
                                                    class="page-item <?php echo e($pesanan->currentPage() == $pesanan->lastPage() ? 'disabled' : ''); ?>">
                                                    <a class="page-link" href="<?php echo e($pesanan->nextPageUrl()); ?>"
                                                        aria-label="Next">
                                                        <span aria-hidden="true">&raquo;</span>
                                                    </a>
                                                </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="siap" role="tabpanel" aria-labelledby="siap-tab" tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Pesanan Siap</h3>
                            <div class="table-responsive" style="margin-top: 20px;">
                                <table class="table table-responsive table-striped table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Pengiriman</th>
                                            <th class="text-center">Pembayaran</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 0 ?>
                                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->status == 'Siap'): ?>
                                        <tr>
                                            <td align="center"><?php echo e(++$no); ?></td>
                                            <td align="center"><?php echo e($value->created_at); ?></td>
                                            <td align="center"><?php echo e($value->no_order); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->grand_total)); ?></td>
                                            <td align="center"><?php echo e($value->metode_pengiriman); ?> </td>
                                            <td align="center"><?php echo e($value->metode_pembayaran); ?> </td>
                                            <td align="center" style="background-color: blue; color: white;">
                                                <?php echo e($value->status); ?></td>
                                            <td align="center">
                                                <button type="button" class="btn btn-primary btn-sm"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#detail<?php echo e($value->id_pesanan); ?>"
                                                    title="Detail Pesanan">
                                                    Detail
                                                </button>
                                                <a href="<?php echo e(url($value->id_pesanan.'/invoice-pesananonline')); ?>"
                                                    target="_blank">
                                                    <button class="btn btn-danger btn-sm">
                                                        <i class="fas fa-file-invoice"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($no == 0): ?>
                                        <tr>
                                            <td colspan="12" align="center">Data tidak ditemukan</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="dikirim" role="tabpanel" aria-labelledby="dikirim-tab"
                            tabindex="0">
                            <h3 style="color: #34495e; margin-top: 30px; font-weight: bold; text-align: center;">
                                Pesanan Dikirim</h3>
                            <div class="table-responsive" style="margin-top: 20px;">
                                <table class="table table-responsive table-striped table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th class="text-center">No</th>
                                            <th class="text-center">Waktu</th>
                                            <th class="text-center">No Order</th>
                                            <th class="text-center">Total</th>
                                            <th class="text-center">Pengiriman</th>
                                            <th class="text-center">Pembayaran</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center">Detail</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 0 ?>
                                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->status == 'Dikirim'): ?>
                                        <tr>
                                            <td align="center"><?php echo e(++$no); ?></td>
                                            <td align="center"><?php echo e($value->created_at); ?></td>
                                            <td align="center"><?php echo e($value->no_order); ?></td>
                                            <td align="center">Rp. <?php echo e(number_format($value->grand_total)); ?></td>
                                            <td align="center"><?php echo e($value->metode_pengiriman); ?> </td>
                                            <td align="center"><?php echo e($value->metode_pembayaran); ?> </td>
                                            <td align="center" style="background-color: gray; color: white;">
                                                <?php echo e($value->status); ?></td>
                                            <td align="center">
                                                <button type="button" class="btn btn-primary btn-sm"
                                                    data-bs-toggle="modal"
                                                    data-bs-target="#detail<?php echo e($value->id_pesanan); ?>"
                                                    title="Detail Pesanan">
                                                    Detail
                                                </button>
                                                <a href="<?php echo e(url($value->id_pesanan.'/invoice-pesananonline')); ?>"
                                                    target="_blank">
                                                    <button class="btn btn-danger btn-sm">
                                                        <i class="fas fa-file-invoice"></i>
                                                    </button>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($no == 0): ?>
                                        <tr>
                                            <td colspan="12" align="center">Data tidak ditemukan</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal" id="detail<?php echo e($value->id_pesanan); ?>" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Detail Pesanan</h4>
            </div>
            <div class="modal-body">
                <table class="table table-responsive table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th class="text-center">No</th>
                            <th class="text-center">Produk</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">QTY</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $counter = 0;
                        $last_order_id = null;
                        ?>

                        <?php $__currentLoopData = $pesananDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($detail->id_pesanan != $last_order_id): ?>
                        <?php
                        $counter = 1;
                        $last_order_id = $detail->id_pesanan;
                        ?>
                        <?php endif; ?>

                        <?php if($detail->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td align="center"><?php echo e($counter); ?></td>
                            <td align="center"><?php echo e($detail->produk->nama); ?></td>
                            <td align="center">Rp. <?php echo e(number_format($detail->produk->harga_jual)); ?></td>
                            <td align="center"><?php echo e($detail->qty); ?></td>
                            <td align="center">Rp. <?php echo e(number_format($detail->total)); ?></td>
                        </tr>
                        <?php $counter++; ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Pengiriman</strong></td>
                            <td style="background-color: #EEEEEE"><strong><?php echo e($value->metode_pengiriman); ?></strong>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2">Alamat</td>
                            <td><?php echo e($kirim->alamat); ?> </td>
                        </tr>
                        <tr>
                            <td colspan="2">Jarak</td>
                            <td><?php echo e($kirim->jarak); ?> KM</td>
                        </tr>
                        <tr>
                            <td colspan="2">Ongkir</td>
                            <td><?php echo e($kirim->ongkir); ?> </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Pembayaran</strong></td>
                            <td style="background-color: #EEEEEE"><strong><?php echo e($value->metode_pembayaran); ?></strong>
                            </td>
                        </tr>
                        <?php $__currentLoopData = $buktiPembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $bukti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($bukti->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2">Bukti Pembayaran</td>
                            <td><a href="images/buktipembayaran/<?php echo e($bukti->foto); ?>" target="_blank"><img
                                        src="images/buktipembayaran/<?php echo e($bukti->foto); ?>" width="100px"></a></td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td>
                                <?php if($bukti->konfirmasi == 'Terkonfirmasi'): ?>
                                <strong><i class="fa fa-check"></i> Terkonfirmasi</strong>
                                <?php else: ?>
                                <form action="<?php echo e(url('konfirmasi-pembayaran')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="bukti_pembayaran_id" value="<?php echo e($bukti->id_bukti); ?>">
                                    <button type="submit" class="btn btn-warning">Konfirmasi Pembayaran</button>
                                </form>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-responsive table-bordered">
                    <tbody>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $kirim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($kirim->id_pesanan == $value->id_pesanan): ?>
                        <tr>
                            <td colspan="2" style="background-color: #EEEEEE"><strong>Total Pembayaran</strong></td>
                            <td style="background-color: #EEEEEE"><strong>Rp
                                    <?php echo e(number_format($kirim->ongkir + $value->grand_total)); ?></strong>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apotek\sistem\resources\views//admin-pesananmasuk.blade.php ENDPATH**/ ?>